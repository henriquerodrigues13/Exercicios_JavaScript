const alunos = [
  { nome: "Ana", nota: 8 },
  { nome: "Bruno", nota: 5 },
  { nome: "Carla", nota: 9 },
];

const [aluno] = alunos;
const nome = aluno.nome;
const nota = aluno.nota;
console.log(aluno);
console.log(nome);
console.log(nota);