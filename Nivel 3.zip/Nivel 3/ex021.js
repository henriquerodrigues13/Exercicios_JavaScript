function resumo(alunos){
    const aprovados = alunos.filter((n) => n.nota > 7);
    const nomesAprovados = aprovados.map((n) => n.nome.toUpperCase());
    const media = alunos.reduce((media, n) => media + n.nota, 0)/alunos.length;
    return `{ ${alunos.length} , ${nomesAprovados}, ${media}}`
}

const alunos = [
  { nome: "Ana", nota: 8 },
  { nome: "Bruno", nota: 5 },
  { nome: "Carla", nota: 9 },
];

console.log(resumo(alunos));